Project name: oracle
Exported on: 02/13/2017 13:47:43
Exported by: ATTUNITY_LOCAL\Ori.Porat
