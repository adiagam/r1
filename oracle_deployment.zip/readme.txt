Project name: oracle
Exported on: 02/13/2017 13:48:41
Exported by: ATTUNITY_LOCAL\Ori.Porat
